import{a}from"./chunk-2LAYQTQL.js";import"./chunk-6MHYDRXN.js";import"./chunk-MB4RORS3.js";export{a as LicenseClientService};
